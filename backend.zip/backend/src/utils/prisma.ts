import { PrismaClient } from "@prisma/client";

export const prisma1 = new PrismaClient();
